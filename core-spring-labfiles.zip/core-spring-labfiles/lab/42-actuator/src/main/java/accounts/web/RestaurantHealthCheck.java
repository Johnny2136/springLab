package accounts.web;

/**
 * TODO-15a: Make this class implement HealthIndicator
 * <p>
 * Add a constructor to pass in the restaurant repository and use it to
 * implement health().
 * <p>
 * health() should return DOWN if the repository is empty (no restaurants) or UP
 * otherwise.
 */
public class RestaurantHealthCheck {

}
