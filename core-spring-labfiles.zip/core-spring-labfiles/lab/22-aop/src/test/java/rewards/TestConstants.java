package rewards;

public class TestConstants {
	
	// TODO-01: Enable checking of console output in our Tests.
	//
	// IMPORTANT NOTE: The JUnit tests you will run in this lab already
	// work. Just getting a green test does not indicate success. You must
	// ALSO get logging messages on the console.
	//
	// To enable our tests to check console output, change this to true.
	
	public static final boolean CHECK_CONSOLE_OUTPUT = false;
}
